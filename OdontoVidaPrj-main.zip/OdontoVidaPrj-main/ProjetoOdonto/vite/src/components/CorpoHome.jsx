const CorpoHome = () => {
    return(
        <div>
            <div className="containerHome">
                <div className="BlocoHomeEsq">
                <h1 className="TitleHome">Seja Bem Vindo!</h1>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Doloremque pariatur ea quae numquam odio aliquid aspernatur reiciendis nulla minima quod quibusdam suscipit quasi magni molestiae quis iste, rerum officiis veniam. Lorem ipsum dolor sit amet consectetur adipisicing elit. Vero sunt harum labore eaque distinctio, repellat iste voluptas, rem nostrum eos aspernatur qui excepturi officia magnam vel. Id alias illo commodi?
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Fuga facere eveniet modi numquam, cupiditate ipsam doloremque quam exercitationem maxime adipisci quaerat temporibus tenetur delectus, quae quibusdam hic, deserunt accusantium officiis. </p>
                
                </div>
                <div className="BlocoHomeDir">
                    <img className="imgHome" src="dentelogo.png" alt="Logo" />
                </div>
            </div>
        </div>
    )
}

export default CorpoHome