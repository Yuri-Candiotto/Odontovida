import Header from "../components/Header";
import CorpoHome from "../components/CorpoHome";

const TelaHome = () => {
    return(
        <div>
            <Header/>
            <CorpoHome/>
        </div>
    )
}

export default TelaHome