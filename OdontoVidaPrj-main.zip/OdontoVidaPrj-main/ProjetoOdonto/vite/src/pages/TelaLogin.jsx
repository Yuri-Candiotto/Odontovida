import Login from '../components/Login'

const TelaLogin = () => {

    return(
        <div>
            <Login/>
        </div>
    )
}

export default TelaLogin