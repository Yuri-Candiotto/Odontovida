const Menu = () => {

    return(
        <div>
            <div className='containerMenu'>
                <div className='childMenu'><button className="styleMenu">Home</button></div>
                <div className='childMenu'><button className="styleMenu">Cadastro</button></div>
                <div className='childMenu'><button className="styleMenu">Agendamento</button></div>
                <div className="childMenu"><button className="styleMenu">Serviços</button></div>
                <div className="childMenu"><button className="styleMenu">Relatórios</button></div>
            </div>
        </div>
    ) 

}

export default Menu