const ParedeLogin = () => {

    return(
        <div>
        <div className="parede">
            <h1>OdontoVida</h1>
        </div>
    
       </div>

    )
}

export default ParedeLogin