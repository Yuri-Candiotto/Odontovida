import Header from "../components/Header";

const TelaHome = () => {
    return(
        <div>
            <Header/>
        </div>
    )
}

export default TelaHome